class car:
    pass
ford = car()
ford.speed = 500
print(ford.speed)